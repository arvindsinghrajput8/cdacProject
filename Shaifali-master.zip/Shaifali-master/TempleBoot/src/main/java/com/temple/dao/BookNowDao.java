package com.temple.dao;

import com.temple.model.BookNow;

public interface BookNowDao {

	public void addBookNow(BookNow booknow);
	
	
}
